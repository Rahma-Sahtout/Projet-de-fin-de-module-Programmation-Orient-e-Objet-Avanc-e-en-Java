package com.zosh.domain;

public enum UserStatus {

    VERIFIED,
    PENDING

}
